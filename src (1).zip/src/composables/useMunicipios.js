/**
 * Composable — Catálogo de municipios del Estado de México
 * Fuente: INEGI Marco Geoestadístico 2020
 *
 * Uso:
 *   import { useMunicipios } from '@/composables/useMunicipios'
 *   const { municipios, busqueda, porCvegeo, porNombre, todos } = useMunicipios()
 */

import { ref, computed } from 'vue'
import catalogoRaw from '@/data/edomex_municipios_nombres.json'

// ─────────────────────────────────────────────────────────────────────────────
// ALIAS — nombres históricos, con sufijo o variantes conocidas en la BD
// Cuando el campo `municipio` trae un nombre no oficial, este mapa lo resuelve
// antes de intentar el match fuzzy.
//
// Patrón frecuente: "Municipio de X" → X, o "X de Apellido" → X
// ─────────────────────────────────────────────────────────────────────────────
const ALIAS = {
  'toluca de lerdo': 'Toluca',
  'jilotepec de molina enriquez': 'Jilotepec',
  'jilotepec de andres molina enriquez': 'Jilotepec',
  'otumba de gomez farias': 'Otumba',
  'chalco de diaz covarrubias': 'Chalco',
  'zumpango de ocampo': 'Zumpango',
  'amanalco de becerra': 'Amanalco',
  'acambay de ruiz castaneda': 'Acambay de Ruíz Castañeda',
  'san mateo atenco': 'San Mateo Atenco',
  'cuautitlan izcalli': 'Cuautitlán Izcalli',
  'valle de chalco solidaridad': 'Valle de Chalco Solidaridad',
  'ecatepec de morelos': 'Ecatepec de Morelos',
  'naucalpan de juarez': 'Naucalpan de Juárez',
  nezahualcoyotl: 'Nezahualcóyotl',
  'tlalnepantla de baz': 'Tlalnepantla de Baz',
  'atizapan de zaragoza': 'Atizapán de Zaragoza',
  'coacalco de berriozabal': 'Coacalco de Berriozábal',
  'nicolas romero': 'Nicolás Romero',
  'san jose del rincon': 'San José del Rincón',
  'soyaniquilpan de juarez': 'Soyaniquilpan de Juárez',
  // Municipios con sufijo geográfico o histórico frecuente en padrones
  'texcoco de mora': 'Texcoco',
  'ixtlahuaca de rayón': 'Ixtlahuaca',
  'ixtlahuaca de rayon': 'Ixtlahuaca',
  'lerma de villada': 'Lerma',
  metepec: 'Metepec',
  'tenango del valle': 'Tenango del Valle',
  'tianguistenco de galeana': 'Tianguistenco',
  'villa nicolas romero': 'Nicolás Romero',
  'tultitlan de mariano escobedo': 'Tultitlán',
  tultitlan: 'Tultitlán',
  'tepetlaoxtoc de hidalgo': 'Tepetlaoxtoc',
  tepotzotlan: 'Tepotzotlán',
  'cuautitlan de romero rubio': 'Cuautitlán',
  huehuetoca: 'Huehuetoca',
  teoloyucan: 'Teoloyucan',
  tecamac: 'Tecámac',
  'villa de allende': 'Villa de Allende',
}

// ─────────────────────────────────────────────────────────────────────────────
// NORMALIZACIÓN
// Minúsculas + sin acentos + sin especiales + espacios colapsados
// "ACAMBAY DE RUIZ CASTAÑEDA" → "acambay de ruiz castaneda"
// ─────────────────────────────────────────────────────────────────────────────
const normalizar = (str) => {
  if (!str) return ''
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // quitar diacríticos
    .replace(/[^a-z0-9\s]/g, ' ') // especiales → espacio
    .replace(/\s+/g, ' ')
    .trim()
}

// Precomputar nombre normalizado una sola vez
const MUNICIPIOS = [...catalogoRaw]
  .map((m) => ({ ...m, _norm: normalizar(m.nombre) }))
  .sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'))

// ─────────────────────────────────────────────────────────────────────────────
// SCORE DE COINCIDENCIA  0-4
//   4 — exacto normalizado
//   3 — query contenido en municipio o municipio en query
//   2 — municipio empieza con query (≥4 chars)
//   1 — todas las palabras del query aparecen en el municipio
//   0 — sin coincidencia
// ─────────────────────────────────────────────────────────────────────────────
const score = (munNorm, q) => {
  if (!q) return 0
  if (munNorm === q) return 4
  if (munNorm.includes(q)) return 3
  if (q.includes(munNorm)) return 3
  if (q.length >= 4 && munNorm.startsWith(q)) return 2
  const palabras = q.split(' ').filter((p) => p.length > 2)
  if (palabras.length && palabras.every((p) => munNorm.includes(p))) return 1
  return 0
}

// ─────────────────────────────────────────────────────────────────────────────
// MATCH PRINCIPAL
// Devuelve { municipio, esExacto } | null
//   municipio — objeto del catálogo { cvegeo, nombre, _norm }
//   esExacto  — true si el match es confiable (score ≥ 3)
//
// Si no hay match → devuelve null (el caller decide qué hacer)
// ─────────────────────────────────────────────────────────────────────────────
const encontrarMunicipio = (nombre) => {
  const q = normalizar(nombre)
  if (!q) return null

  // 1. Buscar en alias primero (nombres históricos / con sufijo)
  if (ALIAS[q]) {
    const encontrado = MUNICIPIOS.find((m) => m.nombre === ALIAS[q])
    if (encontrado) return { municipio: encontrado, esExacto: true }
  }

  // 2. Match fuzzy contra el catálogo
  let mejor = null
  let mejorScore = 0

  for (const m of MUNICIPIOS) {
    const s = score(m._norm, q)
    if (s > mejorScore) {
      mejorScore = s
      mejor = m
      if (s === 4) break
    }
  }

  if (!mejor || mejorScore === 0) return null

  return {
    municipio: mejor,
    esExacto: mejorScore >= 3,
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// COMPOSABLE
// ─────────────────────────────────────────────────────────────────────────────
export function useMunicipios() {
  const busqueda = ref('')

  // Lista filtrada y ordenada por score
  const municipios = computed(() => {
    const q = normalizar(busqueda.value)
    if (!q) return MUNICIPIOS

    return MUNICIPIOS.map((m) => ({ m, s: score(m._norm, q) }))
      .filter(({ s }) => s > 0)
      .sort((a, b) => b.s - a.s)
      .map(({ m }) => m)
  })

  // Buscar por cvegeo exacto
  const porCvegeo = (cvegeo) => MUNICIPIOS.find((m) => m.cvegeo === cvegeo) ?? null

  /**
   * porNombre — tolera cualquier variante del nombre
   *
   * Devuelve:
   *   { cvegeo, nombre }  si encontró municipio con confianza
   *   null                si es una localidad u otro nombre no reconocible
   *
   * El caller decide qué hacer con null:
   *   → mostrar el registro sin resaltar polígono (comportamiento deseado)
   */
  const porNombre = (nombre) => {
    const resultado = encontrarMunicipio(nombre)
    if (!resultado) return null
    // Solo devolver si es match confiable
    // Score bajo (1-2) puede ser falso positivo con localidades
    return resultado.esExacto ? resultado.municipio : null
  }

  /**
   * porNombreForzado — igual pero devuelve el mejor match aunque no sea exacto
   * Útil para el buscador interactivo donde el usuario ya eligió explícitamente
   */
  const porNombreForzado = (nombre) => {
    const resultado = encontrarMunicipio(nombre)
    return resultado?.municipio ?? null
  }

  const todos = MUNICIPIOS

  return { municipios, busqueda, porCvegeo, porNombre, porNombreForzado, todos, normalizar }
}
