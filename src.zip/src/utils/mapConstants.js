// Niveles de zoom del mapa
// Importar en MapView.vue y PadronMapView.vue

// Zoom al que se activa la vista de municipios (clusters del servidor)
export const ZOOM_MUNICIPIO = 10

// Zoom al que se activa la vista de secciones (intermedio)
export const ZOOM_SECCION = 13

// Zoom al que se activa la vista de puntos individuales (CircleMarkers)
// Subido de 13 a 14 para dar más margen antes de pedir los 15k puntos
export const ZOOM_PUNTO = 14
