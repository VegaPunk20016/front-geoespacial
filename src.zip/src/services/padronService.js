import api from './api'

export default {
  getAll() {
    return api.get('/padrones')
  },

  getById(id) {
    return api.get(`/padrones/${id}`)
  },

  getBeneficiarios(id, coords = null) {
    let url = `/padrones/${id}/beneficiarios`
    if (coords) {
      const query = new URLSearchParams(coords).toString()
      url += `?${query}`
    }

    return api.get(url)
  },
  // 🔴 ZONA DE JEFES (Admin)
  create(data) {
    return api.post('/padrones', data)
  },

  importCsv(id, file) {
    const formData = new FormData()
    formData.append('archivo', file)

    return api.post(`/padrones/${id}/importar`, formData, {
      headers: {
        'Content-Type': undefined,
      },
      onUploadProgress: (progressEvent) => {
        const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total)
        console.log(`Subiendo: ${percentCompleted}%`)
      },
    })
  },

  delete(id, permanente = false) {
    return api.delete(`/padrones/${id}?permanente=${permanente}`)
  },

  // Alias para compatibilidad con padronStore que llama .eliminar()
  eliminar(id, permanente = false) {
    return this.delete(id, permanente)
  },
}
