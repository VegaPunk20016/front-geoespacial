<template>
  <div class="h-screen w-full flex flex-col relative overflow-hidden">
    <div class="fixed top-24 left-6 z-[1000] flex flex-col gap-3">
      <button
        @click="router.back()"
        class="bg-[#012737] text-white p-4 rounded-2xl shadow-xl flex items-center gap-3 hover:bg-[#177DA6] transition-all"
      >
        <ArrowLeft size="18" /> <span class="font-bold text-sm text-white">Regresar</span>
      </button>

      <div class="bg-white/90 backdrop-blur px-5 py-3 rounded-2xl shadow-xl border border-white">
        <p class="text-[10px] font-black text-gray-400 uppercase tracking-widest">En pantalla</p>
        <div class="flex items-center gap-2">
          <div class="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
          <span class="text-xl font-black text-[#012737]">{{ beneficiarios.length }}</span>
        </div>
      </div>
    </div>

    <main class="flex-1">
      <MapView
        :registros="beneficiarios"
        :seleccionado="registroSeleccionado"
        @view-change="onMapMove"
        @select="(reg) => (registroSeleccionado = reg)"
      />
    </main>

    <Transition name="slide-up">
      <div
        v-if="registroSeleccionado"
        class="absolute bottom-10 left-1/2 -translate-x-1/2 z-[2000] w-full max-w-md px-4"
      >
        <div class="bg-white rounded-[2rem] shadow-2xl p-6 border border-gray-100">
          <div class="flex justify-between items-start mb-4">
            <div>
              <h3 class="font-black text-[#012737] text-lg leading-tight">
                {{ registroSeleccionado.nombre_completo }}
              </h3>
              <p class="text-xs font-bold text-[#177DA6] uppercase tracking-tighter">
                {{ registroSeleccionado.municipio }}
              </p>
            </div>
            <button @click="registroSeleccionado = null" class="bg-gray-100 p-2 rounded-full">
              <X size="16" />
            </button>
          </div>
          <div class="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto pr-2">
            <div
              v-for="(v, k) in parseExtra(registroSeleccionado.datos_generales)"
              :key="k"
              class="bg-gray-50 p-2 rounded-xl"
            >
              <p class="text-[8px] font-bold text-gray-400 uppercase">{{ k }}</p>
              <p class="text-[10px] font-bold text-[#012737] truncate">{{ v }}</p>
            </div>
          </div>
        </div>
      </div>
    </Transition>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { storeToRefs } from 'pinia'
import { usePadronStore } from '@/stores/padronStore'
import MapView from '@/components/MapView.vue'
import { ArrowLeft, X } from 'lucide-vue-next'

const route = useRoute()
const router = useRouter()
const store = usePadronStore()
const { beneficiarios } = storeToRefs(store)
const registroSeleccionado = ref(null)
let debounceTimer = null

const onMapMove = (coords) => {
  if (coords.zoom < 8) return
  clearTimeout(debounceTimer)
  debounceTimer = setTimeout(() => {
    store.fetchBeneficiarios(route.params.id, coords)
  }, 400)
}

const parseExtra = (data) => (typeof data === 'string' ? JSON.parse(data) : data)

onMounted(() => store.fetchBeneficiarios(route.params.id))
</script>

<style scoped>
.slide-up-enter-active,
.slide-up-leave-active {
  transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
}
.slide-up-enter-from,
.slide-up-leave-to {
  transform: translate(-50%, 120%);
  opacity: 0;
}
</style>
