<template>
  <div ref="mapContainer" class="w-full h-full bg-[#f8fafc] z-0"></div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, watch, shallowRef, nextTick } from 'vue'
import L from 'leaflet'

// Estilos de Leaflet y Clusters
import 'leaflet/dist/leaflet.css'
import 'leaflet.markercluster/dist/MarkerCluster.css'
import 'leaflet.markercluster/dist/MarkerCluster.Default.css'
import 'leaflet.markercluster'

const props = defineProps({
  registros: { type: Array, default: () => [] },
  seleccionado: { type: Object, default: null },
})

const emit = defineEmits(['select', 'view-change', 'error-cartografia'])

const mapContainer = ref(null)
const map = shallowRef(null)
const clusterLayer = shallowRef(null)
const limitesLayer = shallowRef(null)

const inicializarMapa = () => {
  if (!mapContainer.value || map.value) return

  // Centro inicial (Estado de México)
  map.value = L.map(mapContainer.value, {
    zoomControl: false,
  }).setView([19.35, -99.63], 10)

  L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; IIDESOFT',
    maxZoom: 20,
  }).addTo(map.value)

  L.control.zoom({ position: 'bottomright' }).addTo(map.value)

  clusterLayer.value = L.markerClusterGroup({
    showCoverageOnHover: false,
    maxClusterRadius: 50,
    iconCreateFunction: (cluster) => {
      const count = cluster.getChildCount()
      return L.divIcon({
        html: `<div class="cluster-bubble">${count}</div>`,
        className: 'custom-cluster-icon',
        iconSize: L.point(40, 40),
      })
    },
  }).addTo(map.value)

  // EVENTO CRÍTICO: Detectar movimiento para BBOX
  map.value.on('moveend', () => {
    const bounds = map.value.getBounds()
    emit('view-change', {
      min_lat: bounds.getSouth(),
      max_lat: bounds.getNorth(),
      min_lng: bounds.getWest(),
      max_lng: bounds.getEast(),
      zoom: map.value.getZoom(),
    })
  })
}

const cargarGeoJSON = async () => {
  try {
    const response = await fetch('/data/edomex.json')
    const data = await response.json()
    limitesLayer.value = L.geoJSON(data, {
      style: {
        color: '#012737',
        weight: 1.5,
        opacity: 0.3,
        fillColor: '#177DA6',
        fillOpacity: 0.02,
      },
    }).addTo(map.value)
  } catch (e) {
    emit('error-cartografia')
  }
}

const dibujarMarcadores = () => {
  if (!clusterLayer.value || !map.value) return
  clusterLayer.value.clearLayers()

  props.registros.forEach((reg) => {
    const lat = parseFloat(reg.latitud)
    const lng = parseFloat(reg.longitud)
    if (isNaN(lat) || isNaN(lng)) return

    const marker = L.marker([lat, lng], {
      icon: L.divIcon({
        className: 'custom-pin-icon',
        html: `<div class="pin-inner"></div>`,
        iconSize: [14, 14],
        iconAnchor: [7, 7],
      }),
    })

    marker.on('click', () => emit('select', reg))
    clusterLayer.value.addLayer(marker)
  })
}

watch(
  () => props.registros,
  () => dibujarMarcadores(),
  { deep: false },
)

watch(
  () => props.seleccionado,
  (nuevo) => {
    if (nuevo && map.value) {
      map.value.flyTo([nuevo.latitud, nuevo.longitud], 17)
    }
  },
)

onMounted(async () => {
  await nextTick()
  inicializarMapa()
  await cargarGeoJSON()
  dibujarMarcadores()
})

onUnmounted(() => {
  if (map.value) map.value.remove()
})
</script>

<style>
.cluster-bubble {
  width: 40px;
  height: 40px;
  background: #177da6;
  color: white;
  border-radius: 50%;
  border: 3px solid white;
  box-shadow: 0 4px 12px rgba(23, 125, 166, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 11px;
  font-weight: 900;
}
.pin-inner {
  width: 14px;
  height: 14px;
  background: #012737;
  border-radius: 50%;
  border: 2px solid white;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}
</style>
