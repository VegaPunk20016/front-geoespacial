<template>
  <div ref="mapContainer" class="w-full h-full bg-[#f8fafc] outline-none"></div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, watch, markRaw, nextTick } from 'vue'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import 'leaflet.markercluster'
import RBush from 'rbush'
import 'leaflet.heat'
import 'leaflet-draw/dist/leaflet.draw.css'
import * as turf from '@turf/turf'

import dataMun from '@/data/edomex_municipios.json'
import dataEnt from '@/data/edomex_estado.json'
import { ZOOM_MUNICIPIO, ZOOM_PUNTO } from '@/utils/mapConstants'

const props = defineProps({
  registros: { type: Array, default: () => [] },
  modo: { type: String, default: 'estado' },
  datosCoropletas: { type: Array, default: () => [] },
  municipioFiltro: { type: String, default: null },
  tieneCoordenadas: { type: Boolean, default: true },
  usarWorkerDiff: { type: Boolean, default: false },
})

// ── CONFIGURACIÓN FASE 2 ────────────────────────────────────────────────
const PREFETCH_PADDING = 0.5 // 50% de margen extra para pre-cargar puntos fuera de vista
const GRID_SNAP_PRECISION = 3 // Redondeo a 3 decimales para maximizar Cache Hits en Redis

const emit = defineEmits(['select', 'view-change', 'municipio-click', 'zoom-nivel'])

const mapContainer = ref(null)

const state = {
  map: null,
  clusterLayer: null,
  pointsLayer: null,
  municipiosLayer: null,
  canvasRenderer: null,
  heatLayer: null,
}

// ── WORKER ───────────────────────────────────────────────────────────────
let _mapWorker = null

const _initWorker = () => {
  if (_mapWorker) return
  _mapWorker = new Worker('/workers/map.worker.js')
  _mapWorker.onmessage = (e) => {
    const { buffer, idsAQuitar } = e.data
    const aAgregar = JSON.parse(new TextDecoder().decode(buffer))
    _aplicarCambiosDiff({ aAgregar, idsAQuitar })
  }
}

// ── ÍNDICES Y MAPAS INTERNOS ─────────────────────────────────────────────
let _markerMap = new Map()
const spatialIndex = new RBush()

// ── THROTTLE DE RENDER ───────────────────────────────────────────────────
let _renderTimer = null
const renderThrottled = () => {
  if (_renderTimer) return
  _renderTimer = setTimeout(() => {
    _renderTimer = null
    renderMarkers()
  }, 200)
}

// ── DEBOUNCE DE MOVEEND CON PREFETCH Y SNAP ──────────────────────────────
let _moveTimer = null

const handleMoveEnd = () => {
  if (_moveTimer) clearTimeout(_moveTimer)

  _moveTimer = setTimeout(() => {
    const b = state.map.getBounds()

    // FASE 2: Prefetch - Calculamos un área 50% más grande que la visible
    const paddedBounds = b.pad(PREFETCH_PADDING)

    // FASE 2: Snap-to-Grid - Redondeamos coordenadas para que el servidor
    // reciba peticiones idénticas y aproveche el Cache de Redis
    const p = GRID_SNAP_PRECISION
    const filters = {
      min_lat: parseFloat(paddedBounds.getSouth().toFixed(p)),
      max_lat: parseFloat(paddedBounds.getNorth().toFixed(p)),
      min_lng: parseFloat(paddedBounds.getWest().toFixed(p)),
      max_lng: parseFloat(paddedBounds.getEast().toFixed(p)),
    }

    const zoom = state.map.getZoom()
    const nivel = zoom >= ZOOM_PUNTO ? 'punto' : zoom >= ZOOM_MUNICIPIO ? 'municipio' : 'estado'

    emit('zoom-nivel', nivel)
    emit('view-change', {
      bounds: [
        [filters.min_lat, filters.min_lng],
        [filters.max_lat, filters.max_lng],
      ],
      zoom,
      nivel,
    })
  }, 500)
}

// ── COROPLETAS ───────────────────────────────────────────────────────────
const coropletaMap = computed(() => {
  if (!props.datosCoropletas?.length) return {}
  return Object.fromEntries(
    props.datosCoropletas.map((d) => [d.municipio?.toUpperCase().trim(), parseInt(d.total) || 0]),
  )
})

const getMunicipioStyle = (feature) => {
  const nombre = feature.properties.nombre?.toUpperCase().trim()
  const esSeleccionado = props.municipioFiltro?.toUpperCase().trim() === nombre

  if (esSeleccionado) {
    return { color: '#0f172a', weight: 3, opacity: 1, fillColor: '#1e293b', fillOpacity: 0.5 }
  }
  return { color: '#1e4a6e', weight: 0.6, opacity: 0.6, fillColor: '#bfdbfe', fillOpacity: 0.45 }
}

// ── INICIALIZACIÓN DEL MAPA ──────────────────────────────────────────────
const initMap = () => {
  if (state.map) return

  state.canvasRenderer = markRaw(L.canvas({ padding: 0.5 }))

  state.map = markRaw(
    L.map(mapContainer.value, {
      zoomControl: false,
      preferCanvas: true,
      renderer: state.canvasRenderer,
      center: [19.35, -99.63],
      zoom: 9,
      bounceAtZoomLimits: false, // Optimización: evita rebotes que disparan peticiones extra
    }),
  )

  L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; INEGI',
    maxZoom: 20,
  }).addTo(state.map)

  state.clusterLayer = markRaw(
    L.markerClusterGroup({
      showCoverageOnHover: false,
      maxClusterRadius: 40,
      disableClusteringAtZoom: 17,
      chunkedLoading: true,
      chunkInterval: 100,
      chunkDelay: 50,
      iconCreateFunction: (c) =>
        L.divIcon({
          html: `<div class="c-bubble">${c.getChildCount()}</div>`,
          className: 'c-icon',
          iconSize: [35, 35],
        }),
    }),
  ).addTo(state.map)

  state.pointsLayer = markRaw(L.layerGroup()).addTo(state.map)

  L.geoJSON(dataEnt, {
    style: { color: '#1e293b', weight: 2, fillOpacity: 0, interactive: false },
  }).addTo(state.map)

  state.municipiosLayer = markRaw(
    L.geoJSON(dataMun, {
      style: getMunicipioStyle,
      onEachFeature: (feature, layer) => {
        layer.on('click', (e) => {
          L.DomEvent.stopPropagation(e)
          emit('municipio-click', feature.properties)
        })
      },
    }),
  ).addTo(state.map)

  state.map.on('moveend', handleMoveEnd)

  state.heatLayer = markRaw(
    L.heatLayer([], {
      radius: 25,
      blur: 15,
      maxZoom: 17,
      gradient: { 0.4: 'blue', 0.6: 'cyan', 0.7: 'lime', 0.8: 'yellow', 1: 'red' },
    }),
  )

  // 1. Configurar capas de dibujo
  const drawnItems = new L.FeatureGroup().addTo(state.map)

  const drawControl = new L.Control.Draw({
    draw: {
      polygon: true,
      circle: true,
      rectangle: true,
      marker: false,
      polyline: false,
      circlemarker: false,
    },
    edit: {
      featureGroup: drawnItems,
    },
  })
  state.map.addControl(drawControl)

  // 2. Evento al terminar de dibujar
  state.map.on(L.Draw.Event.CREATED, (e) => {
    const layer = e.layer
    drawnItems.clearLayers() // Solo permitimos una selección a la vez
    drawnItems.addLayer(layer)

    procesarSeleccionEspacial(layer)
  })
}

const procesarSeleccionEspacial = (layer) => {
  let puntosDentro = []

  // Obtenemos los límites del dibujo para reducir la búsqueda con RBush
  const bounds = layer.getBounds()
  const candidatos = spatialIndex.search({
    minX: bounds.getWest(),
    minY: bounds.getSouth(),
    maxX: bounds.getEast(),
    maxY: bounds.getNorth(),
  })

  if (layer instanceof L.Circle) {
    // Filtrado por radio para círculos
    const center = layer.getLatLng()
    const radius = layer.getRadius()
    puntosDentro = candidatos.filter((c) => {
      const puntoLatLng = L.latLng(c.minY, c.minX)
      return center.distanceTo(puntoLatLng) <= radius
    })
  } else {
    // Filtrado por polígono usando Turf.js (más preciso)
    const polygonGeoJSON = layer.toGeoJSON()
    puntosDentro = candidatos.filter((c) => {
      const pt = turf.point([c.minX, c.minY])
      return turf.booleanPointInPolygon(pt, polygonGeoJSON)
    })
  }

  // 3. Emitir los resultados para el panel de estadísticas
  emit('area-selected', {
    total: puntosDentro.length,
    registros: puntosDentro.map((p) => p.data),
  })
}

// ── LÓGICA DE RENDERIZADO ────────────────────────────────────────────────
const renderMarkers = () => {
  if (!state.map) return

  // Limpiamos todo antes de decidir qué modo dibujar
  _clearAll()

  if (props.modo === 'calor') {
    _renderHeatmap()
  } else if (props.modo === 'clusters') {
    _renderClusters()
  } else {
    _renderPuntos()
  }
}

const _renderHeatmap = () => {
  // Convertimos los registros a formato [lat, lng, intensidad]
  const heatPoints = props.registros.map((r) => [
    parseFloat(r.latitud || r.lat),
    parseFloat(r.longitud || r.lng),
    1, // Intensidad base (podría ser un campo del JSON en el futuro)
  ])

  state.heatLayer.setLatLngs(heatPoints).addTo(state.map)
}

const _clearAll = () => {
  state.clusterLayer.clearLayers()
  state.pointsLayer.clearLayers()
  if (state.map.hasLayer(state.heatLayer)) state.map.removeLayer(state.heatLayer)
  spatialIndex.clear()
  _markerMap.clear()
}

// ── CLUSTERS DEL SERVIDOR (CircleMarkers vía Canvas) ─────────────────────
const _renderClusters = () => {
  state.clusterLayer.clearLayers()
  state.pointsLayer.clearLayers()
  spatialIndex.clear()
  _markerMap.clear()

  props.registros.forEach((r) => {
    const lat = parseFloat(r.lat)
    const lng = parseFloat(r.lng)
    if (isNaN(lat) || isNaN(lng)) return

    L.circleMarker([lat, lng], {
      renderer: state.canvasRenderer,
      radius: Math.min(5 + Math.sqrt(r.count || 1) * 2, 40),
      fillColor: '#3b82f6',
      color: '#fff',
      weight: 1.5,
      fillOpacity: 0.8,
    })
      .on('click', () => emit('select', r))
      .addTo(state.pointsLayer)
  })
}

// ── PUNTOS INDIVIDUALES (Optimización Canvas + CircleMarker) ─────────────
const _renderPuntos = () => {
  if (props.usarWorkerDiff) {
    _initWorker()
    _mapWorker.postMessage({
      nuevos: props.registros,
      prevIds: Array.from(_markerMap.keys()),
    })
  } else {
    _reemplazarTodo(props.registros)
  }
}

const _reemplazarTodo = (registros) => {
  state.clusterLayer.clearLayers()
  _markerMap.clear()

  const markers = _crearCircleMarkers(registros)
  if (markers.length) state.clusterLayer.addLayers(markers)

  _rebuildSpatialIndex(registros)
}

const _aplicarCambiosDiff = ({ aAgregar, idsAQuitar }) => {
  idsAQuitar.forEach((id) => {
    const m = _markerMap.get(id)
    if (m) {
      state.clusterLayer.removeLayer(m)
      _markerMap.delete(id)
    }
  })

  const markers = _crearCircleMarkers(aAgregar)
  if (markers.length) state.clusterLayer.addLayers(markers)

  _rebuildSpatialIndex(props.registros)
}

const _crearCircleMarkers = (registros) => {
  const markers = []

  registros.forEach((r) => {
    const lat = parseFloat(r.latitud ?? r.lat)
    const lng = parseFloat(r.longitud ?? r.lng)
    if (isNaN(lat) || isNaN(lng)) return

    const m = L.circleMarker([lat, lng], {
      renderer: state.canvasRenderer,
      radius: 5,
      fillColor: '#0f172a',
      color: '#ffffff',
      weight: 1,
      fillOpacity: 0.85,
    }).on('click', () => emit('select', r))

    _markerMap.set(r.id, m)
    markers.push(m)
  })

  return markers
}

// ── R-TREE (Índice Espacial en Cliente) ──────────────────────────────────
const _rebuildSpatialIndex = (registros) => {
  spatialIndex.clear()
  spatialIndex.load(
    registros.map((r) => {
      const lat = parseFloat(r.latitud ?? r.lat)
      const lng = parseFloat(r.longitud ?? r.lng)
      return { minX: lng, minY: lat, maxX: lng, maxY: lat, id: r.id, data: r }
    }),
  )
}

// ── API EXPUESTA AL COMPONENTE PADRE ─────────────────────────────────────
defineExpose({
  zoomToMunicipio: (nombre) => {
    if (!state.municipiosLayer || !nombre) return
    const layer = state.municipiosLayer
      .getLayers()
      .find((l) => l.feature?.properties?.nombre?.toUpperCase() === nombre.toUpperCase())
    if (layer) state.map.fitBounds(layer.getBounds(), { padding: [20, 20] })
  },

  resetView: () => state.map?.flyTo([19.35, -99.63], 9),

  queryArea: (minLat, minLng, maxLat, maxLng) =>
    spatialIndex.search({ minX: minLng, minY: minLat, maxX: maxLng, maxY: maxLat }),

  getZoom: () => state.map?.getZoom(),
})

// ── WATCHERS ─────────────────────────────────────────────────────────────
watch(() => props.registros, renderThrottled, { deep: false })

watch([() => props.datosCoropletas, () => props.municipioFiltro], () => {
  state.municipiosLayer?.setStyle(getMunicipioStyle)
})

// ── LIFECYCLE ────────────────────────────────────────────────────────────
onMounted(async () => {
  await nextTick()
  initMap()
})

onUnmounted(() => {
  if (_renderTimer) clearTimeout(_renderTimer)
  if (_moveTimer) clearTimeout(_moveTimer)
  if (_mapWorker) _mapWorker.terminate()

  _markerMap.clear()
  spatialIndex.clear()
  state.map?.remove()
})
</script>

<style>
.map-container {
  will-change: transform;
}
.c-bubble {
  width: 35px;
  height: 35px;
  background: #3b82f6;
  color: white;
  border-radius: 50%;
  border: 2px solid white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 10px;
  font-weight: 800;
  box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
}

.c-icon {
  background: transparent;
  border: none;
}

/* Mantenidos por compatibilidad con otros componentes */
.p-icon {
  background: transparent;
  border: none;
}
.p-dot {
  width: 10px;
  height: 10px;
  background: #0f172a;
  border: 1.5px solid white;
  border-radius: 50%;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}
</style>
